package com.example.raghu.flowlayoutdemo;

import android.app.Activity;
import android.os.Bundle;

public class FlowLayoutActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}