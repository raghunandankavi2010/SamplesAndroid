package com.example.raghu.databindingaac;


import android.os.Bundle;

import android.text.Editable;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProviders;

import com.example.raghu.databindingaac.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);


        final MyViewModel model = ViewModelProviders.of(this).get(MyViewModel.class);

        binding.setViewModel(model);

        binding.button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                model.check();

            }
        });

        TextWatcherAdapter watcher = new TextWatcherAdapter() {
            @Override public void afterTextChanged(Editable s) {
                model.check();
            }
        };
        //binding.editInput.addTextChangedListener(watcher);
       // binding.editInput2.addTextChangedListener(watcher);

    }

}
